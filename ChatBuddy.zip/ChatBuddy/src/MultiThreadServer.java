import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.ArrayList;

public class MultiThreadServer extends Thread {

	private static ArrayList<User> users = new ArrayList<>();

	private Socket client;
	private DBManager db;
	private ObjectOutputStream oos;
	private ObjectInputStream ois;
	private SerevrChatUI ui;

	public MultiThreadServer(Socket client) {
		this.client = client;
		db = new DBManager();

//		names.add(new User("AliAwan", "123456"));
//		names.add(new User("Ajeeb", "ajeeb"));
//		names.add(new User("Najeeb", "123456"));
	}

	private String valideSignUP(String username, String password) {
		System.out.println("validate SignUp received: " + username + "  " + password);
		return db.validateSignup(username, password);
	}

	public String validateLogin(String username, String password) {
		System.out.println("validate Login received: " + username + "  " + password);
		return db.checkUser(username, password);

	}

	public void run() {
		
		try {
			ois = new ObjectInputStream(client.getInputStream());
			oos = new ObjectOutputStream(client.getOutputStream());

			while (true) {
				Packet packet = (Packet) ois.readObject();
				System.out.println("MSG From Client of type " + packet.getType());
				String responce = "";
				Packet p;
				switch (packet.getType()) {
				case LOGIN:
					printUsers();
					responce = validateLogin(packet.getUsername(), packet.getPassword());
					if (responce.equals("OK")) {
						startUI(packet.getUsername());
						users.add(new User(packet.getUsername(),this.client));
					}
					p = new Packet(PacketType.LOGIN, responce);
					sendMessage(p);
					break;
				case SIGN_UP:
					responce = valideSignUP(packet.getUsername(), packet.getPassword());
					p = new Packet(PacketType.SIGN_UP, responce);
					sendMessage(p);
					break;
				case MSG:
					if (packet.getReceievr() == null || packet.getReceievr().equals("")) {
						packet.setReceiver("Server");
					}
					db.addMessage(packet);
//					for (User user : users) {
//						if (user.getUser().equals(packet.getReceievr())) {
//							System.out.println("Writing msg to: "+packet.getReceievr());
//							ObjectOutputStream ooslocal = new ObjectOutputStream(user.getSocket().getOutputStream());
//							ooslocal.writeObject(packet);
//							break;
//						}
//					}
					//sendMessagetoAllOnlineUsers();
					ui.addMessage(packet.getMsg(), packet.getUsername(), packet.getReceievr());

				default:
					responce = "ERROR";
				}
			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void startUI(String user) {
		ui = new SerevrChatUI(user, this);
		ui.setVisible(true);
	}

	public void sendMessage(Packet packet) {
		// TODO will do it soon
		Thread sender = new Thread(new Runnable() {

			@Override
			public void run() {
				// TODO Auto-generated method stub
				try {
					oos.writeObject(packet);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		});

		sender.start();

	}
	public void sendMessagetoAllOnlineUsers() {

		// TODO will do it soon
		Thread sender = new Thread(new Runnable() {

			@Override
			public void run() {
				// TODO Auto-generated method stub
				db.messagesBroadcast(users);
			}
		});

		sender.start();

	}

	
	public static void printUsers(){
		if (!users.isEmpty()) {
			for (User user : users) {
				System.out.println("username: "+user.getUser());
			}
		}
		else{
			System.out.println("There is no user online yet!");
		}
	}

}
