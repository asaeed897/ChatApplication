import java.net.Socket;

public class User {
	
	private String username;
	private Socket client;
	
	
	public User(String user, Socket client) {
		this.username = user;
		this.client = client;
	}


	public String getUser() {
		return username;
	}


	public void setUserName(String userName) {
		this.username = userName;
	}


	public Socket getSocket() {
		return client;
	}


	public void setSocket(Socket client) {
		this.client = client;
	}
	
	
}
