import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;

public class Server {

	private ArrayList<User> users = new ArrayList<>();
	private User user;

	public Server() {
		
	}

//	private String valideSignUP(String username, String password) {
//		if (username != null && username.length() >= 3) {
//			if (password != null && password.length() >= 5) {
//				User u = new User(username, password);
//				names.add(u);
//				return "USER ADDED";
//			}
//			return "INVALID PASSWORD";
//		}
//		return "INVALID USERNAME";
//	}
//
//	public String validateLogin(String username, String password) {
//		System.out.println("validate Login received: " + username + "  " + password);
//		for (int i = 0; i < names.size(); i++) {
//			User u = names.get(i);
//			if (username.equalsIgnoreCase(u.getUser()) && password.equals(u.getPassword())) {
//
//				return "OK";
//			}
//		}
//		return "INVALID USER";
//	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			Server server = new Server();

			ServerSocket ss = new ServerSocket(5000);
			System.out.println("Server Listening...");

			while(true) {
				Socket client = ss.accept();
				System.out.println("Client Port number: "+client.getPort());
				
//				ObjectInputStream ois = new ObjectInputStream(client.getInputStream());
//				String username = (String) ois.readObject();
//				server.user = new User(username,client);
				
				//server.users.add(new User(null,client));
				
				System.out.println("Client Connected ");
				MultiThreadServer thread = new MultiThreadServer(client);
				thread.start();
				
			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
