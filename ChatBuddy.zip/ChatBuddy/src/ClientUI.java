import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.GridLayout;
import java.awt.TextArea;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.SwingConstants;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.CardLayout;
import javax.swing.JTextArea;
import java.awt.Rectangle;

public class ClientUI extends JFrame {

	private JPanel contentPane;
	private JTextField textSend;
	private JTextArea textArea;
	private JButton btnSend;
	//private String user;
	private Client client;

	

	/**
	 * Create the frame.
	 */
	public ClientUI(Client client) {
		setBounds(new Rectangle(0, 0, 520, 330));
		//this.user = user;
		this.client = client;
		
		setTitle("Client: "+client.username+"  >");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 519, 339);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		
		JScrollPane scrollPane = new JScrollPane();
		contentPane.add(scrollPane, BorderLayout.CENTER);
		
		textArea = new JTextArea();
		scrollPane.setViewportView(textArea);
		
		JPanel panel = new JPanel();
		contentPane.add(panel, BorderLayout.SOUTH);
		panel.setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));
		
		textSend = new JTextField();
		panel.add(textSend);
		textSend.setColumns(30);
		
		btnSend = new JButton("Send");
		panel.add(btnSend);
		
		btnSend.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				 String text = textSend.getText();
				 addMessage(text, "Me");
				 //Packet packet = new Packet(client.username,text,PacketType.MSG);
				 Packet packet2 = new Packet(PacketType.MSG,client.username,"asim",text);
				//client.sendMessage(packet);
				 client.sendMessage(packet2);
				 
			}
		});
	}
	
	public void addMessage(String msg,String sender){
		 textArea.setText(textArea.getText()+"\n"+sender+": "+msg);
	}
	
	public void setStatus(String status){
		setTitle("Client: "+client.username+"  >"+status);
	}

}
