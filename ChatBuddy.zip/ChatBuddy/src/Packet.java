import java.io.Serializable;

public class Packet implements Serializable{
	private PacketType type;
	private String username;
	private String password;
	private String receiver;
	private String Msg;
	
	public Packet(PacketType type, String username, String password) {
		this.type = type;
		this.username = username;
		this.password = password;
	}
	
	public Packet(String username, String Msg ,PacketType type) {
		this.type = type;
		this.username = username;
		this.Msg = Msg;
	}
	
	public Packet(PacketType type,String username,String receiver, String Msg) {
		this.type = type;
		this.username = username;
		this.receiver = receiver;
		this.Msg = Msg;
	}

	public Packet(PacketType type, String Msg) {
		this.type = type;
		this.Msg = Msg;
	}
	
	public PacketType getType() {
		return type;
	}

	public void setType(PacketType type) {
		this.type = type;
	}

	public String getUsername() {
		return username;
	}
	public String getReceievr() {
		return receiver;
	}
	
	public void setUsername(String username) {
		this.username = username;
	}
	public void setReceiver(String receiver) {
		this.receiver = receiver;
	}


	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getMsg() {
		return Msg;
	}

	public void setMsg(String msg) {
		this.Msg = msg;
	}
	
	
	
}
