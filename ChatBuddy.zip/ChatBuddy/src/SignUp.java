import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import javax.swing.JLabel;
import java.awt.Color;

public class SignUp extends JFrame {

	private JPanel contentPane;
	private JTextField textUsername;
	private JPasswordField passwordField;
	private JLabel lblErrorMessage;
	Client client;
	

	/**
	 * Create the frame.
	 */
	public SignUp(Client client) {
		this.client = client;
		
		setTitle("Sign Up");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 430);
		contentPane = new JPanel();
		contentPane.setForeground(Color.RED);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		textUsername = new JTextField();
		textUsername.setToolTipText("");
		textUsername.setBounds(135, 134, 166, 25);
		contentPane.add(textUsername);
		textUsername.setColumns(10);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(135, 186, 166, 25);
		contentPane.add(passwordField);
		
		JButton btnNewButton = new JButton("Sign Up");
		btnNewButton.setBounds(167, 261, 89, 23);
		contentPane.add(btnNewButton);
		
		JLabel lblUsername = new JLabel("Username");
		lblUsername.setBounds(135, 114, 77, 14);
		contentPane.add(lblUsername);
		
		JLabel lblPassword = new JLabel("Password");
		lblPassword.setBounds(135, 170, 77, 14);
		contentPane.add(lblPassword);
		
		lblErrorMessage = new JLabel("");
		lblErrorMessage.setForeground(Color.RED);
		lblErrorMessage.setBounds(135, 237, 166, 14);
		contentPane.add(lblErrorMessage);
		
		btnNewButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				String username = textUsername.getText();
				String password = passwordField.getText();
				
				Packet packet = new Packet(PacketType.SIGN_UP,username,password);
				
				client.sendMessage(packet);
				
			}
		});
	}
	
	public void showErrorMessage(String msg){
		lblErrorMessage.setText(msg); 
	}
}
