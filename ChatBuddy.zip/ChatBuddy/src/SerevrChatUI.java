import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.GridLayout;
import java.awt.TextArea;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.swing.SwingConstants;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.CardLayout;
import javax.swing.JTextArea;
import java.awt.Rectangle;

public class SerevrChatUI extends JFrame {

	private JPanel contentPane;
	private JTextField textSend;
	private JTextArea textArea;
	private JButton btnSend;
	private String user;
	private MultiThreadServer server;

	

	/**
	 * Create the frame.
	 */
	public SerevrChatUI(String user,MultiThreadServer server) {
		setBounds(new Rectangle(0, 0, 520, 330));
		this.user = user;
		this.server = server;
		
		setTitle("Server: "+user);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 519, 339);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		
		JScrollPane scrollPane = new JScrollPane();
		contentPane.add(scrollPane, BorderLayout.CENTER);
		
		textArea = new JTextArea();
		scrollPane.setViewportView(textArea);
		
		JPanel panel = new JPanel();
		contentPane.add(panel, BorderLayout.SOUTH);
		panel.setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));
		
		textSend = new JTextField();
		panel.add(textSend);
		textSend.setColumns(30);
		
		btnSend = new JButton("Send");
		panel.add(btnSend);
		
		btnSend.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				 String text = textSend.getText();
				 addMessage(text, "Server","Client");
				 Packet packet = new Packet(PacketType.MSG,text);
				 server.sendMessage(packet);
				 
			}
		});
		
		textSend.addKeyListener(new KeyListener() {
			
			@Override
			public void keyTyped(KeyEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void keyReleased(KeyEvent e) {
				// TODO Auto-generated method stub
				Packet packet = new Packet(PacketType.MSG,"!TypingReleased!");
				server.sendMessage(packet);
			}
			
			@Override
			public void keyPressed(KeyEvent e) {
				// TODO Auto-generated method stub
				//JOptionPane.showMessageDialog(null,"KeyPressed"+e);
				Packet packet = new Packet(PacketType.MSG,"!Typing!");
				server.sendMessage(packet);
			}
		});
	}
	
	public void addMessage(String msg,String sender, String receiver){
		 textArea.setText(textArea.getText()+"\n"+sender+": "+msg+" for: "+receiver);
	}

}
