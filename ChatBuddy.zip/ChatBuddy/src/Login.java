import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import javax.swing.JLabel;
import java.awt.Color;
import javax.swing.JTextPane;

public class Login extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JPasswordField passwordField;
	private JLabel lblErrorMessage;
	Client client;
	private JLabel lblWantToCreate;
	private JButton btnCreateAccount;
	

	/**
	 * Create the frame.
	 */
	public Login(Client client) {
		this.client = client;
		
		setTitle("Login");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 430);
		contentPane = new JPanel();
		contentPane.setForeground(Color.RED);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		textField = new JTextField();
		textField.setToolTipText("");
		textField.setBounds(135, 87, 166, 25);
		contentPane.add(textField);
		textField.setColumns(10);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(135, 136, 166, 25);
		contentPane.add(passwordField);
		
		JButton btnNewButton = new JButton("Login");
		btnNewButton.setBounds(172, 193, 89, 23);
		contentPane.add(btnNewButton);
		
		JLabel lblUsername = new JLabel("Username");
		lblUsername.setBounds(135, 73, 117, 14);
		contentPane.add(lblUsername);
		
		JLabel lblPassword = new JLabel("Password");
		lblPassword.setBounds(135, 123, 117, 14);
		contentPane.add(lblPassword);
		
		lblErrorMessage = new JLabel("");
		lblErrorMessage.setForeground(Color.RED);
		lblErrorMessage.setBounds(135, 172, 166, 14);
		contentPane.add(lblErrorMessage);
		
		lblWantToCreate = new JLabel("     Want to Create an Account!");
		lblWantToCreate.setBounds(135, 237, 180, 14);
		contentPane.add(lblWantToCreate);
		
		btnCreateAccount = new JButton("Create Account");
		btnCreateAccount.setBounds(158, 277, 117, 23);
		contentPane.add(btnCreateAccount);
		
		btnNewButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				String username = textField.getText();
				String password = passwordField.getText();
				
				Packet packet = new Packet(PacketType.LOGIN,username,password);
				
				client.sendMessage(packet);
				
			}
		});
		
		btnCreateAccount.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				client.signup = new SignUp(client);
				client.signup.setVisible(true);
				client.login.dispose();
			}
		});
	}
	
	public void showErrorMessage(String msg){
		lblErrorMessage.setText(msg); 
	}
}
