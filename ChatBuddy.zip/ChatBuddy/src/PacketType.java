
public enum PacketType {
	LOGIN,
	SIGN_UP,
	MSG
}
