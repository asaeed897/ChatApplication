import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

public class Client {
	public Login login;
	public SignUp signup;
	public ObjectOutputStream oos;
	public ObjectInputStream ois;
	private ClientUI chatui;
	public String username;
	
	

	public Client() {
		startLoginUI();
		Socket client;
		try {
			client = new Socket("localhost", 5000);
			System.out.println("Connected to Server");
			System.out.println("Client Side local prot number: "+client.getLocalPort());
			oos = new ObjectOutputStream(client.getOutputStream());
			ois = new ObjectInputStream(client.getInputStream());

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	
	public void startLoginUI() {
		this.login = new Login(this);
		this.login.setVisible(true);
	}

	public void sendMessage(Packet packet) {
		username = packet.getUsername();

		Thread sender = new Thread(new Runnable() {

			@Override
			public void run() {
				// TODO Auto-generated method stub
				try {
					oos.writeObject(packet);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		});

		sender.start();
	}
	
//	public User addusername(User user){
//		user.setUserName(this.username);
//		return user;
//	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Client cli = new Client();

		// String msg=(String) ois.readObject();
		// System.out.println("MSG From Server: "+msg);

		Thread receiver = new Thread(new Runnable() {

			@Override
			public void run() {
				// TODO Auto-generated method stub
				try {
					while (true) {
						Packet packet = (Packet) cli.ois.readObject();
						System.out.println("Msg from Server: " + packet.getMsg());

						if (packet.getType() == PacketType.LOGIN) {
							cli.login.showErrorMessage(packet.getMsg());
							
						}else if (packet.getType() == PacketType.SIGN_UP) {
							cli.signup.showErrorMessage(packet.getMsg());
							
						}else if(packet.getMsg().equals("!Typing!")){
							cli.chatui.setStatus("Typing");
						}
						else if(packet.getMsg().equals("!TypingReleased!")){
							try {
								Thread.sleep(300);
							} catch (InterruptedException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
							cli.chatui.setStatus("");
						}
						else if (packet.getType() == PacketType.MSG ) {
							cli.chatui.addMessage(packet.getMsg(), packet.getReceievr());
						}

						if (packet.getMsg().equals("OK")) {
							cli.login.dispose();
							cli.chatui = new ClientUI(cli);
							cli.chatui.setVisible(true);
						}
						
						else if (packet.getMsg().equals("USER ADDED")) {
							cli.signup.dispose();
							cli.startLoginUI();
						}
												
					}
				} catch (ClassNotFoundException | IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		});

		receiver.start();

	}
}
